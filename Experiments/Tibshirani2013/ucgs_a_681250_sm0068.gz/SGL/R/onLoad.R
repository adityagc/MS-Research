.onLoad=function(libname,pkgname)
{
  cat("**********Loaded SGL**********","\n","Please note. Very few kittens were harmed in this implementation of the Sparse Group Lasso.","\n") 
}
